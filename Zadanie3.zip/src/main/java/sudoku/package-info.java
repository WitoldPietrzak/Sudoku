/**
 * Package containing class generating valid sudoku board.
 */
package sudoku;
